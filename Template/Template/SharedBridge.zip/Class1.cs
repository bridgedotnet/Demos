﻿#if BRIDGE
using Bridge;
using Bridge.Html5;
#else
using System;
#endif

namespace $safeprojectname$
{
    public class Class1
    {
        public Class1()
        {

        }
    }
}
